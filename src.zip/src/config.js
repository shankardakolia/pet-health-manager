const API_BASE = "https://petmanagement-two.vercel.app/api";
export default API_BASE;
