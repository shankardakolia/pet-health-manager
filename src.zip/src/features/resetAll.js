// features/reset.js
export const RESET_ALL_STATE = "RESET_ALL_STATE";
export const resetAllState = () => ({ type: RESET_ALL_STATE });

/* In slices: */

