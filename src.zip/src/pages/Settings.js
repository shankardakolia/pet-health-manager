import React from 'react';

export default function Settings() {
  return (
    <div>
      <h1>Settings</h1>
      {/* Implement Settings UI */}
    </div>
  );
}
